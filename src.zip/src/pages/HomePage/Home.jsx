import React from 'react'
import About from './About'
import Services from './Services'
import DesignProcess from './DesignProcess'

function Home() {
  return (
    <>
      <About />
      <Services />
      <DesignProcess />
    </>
  )
}

export default Home
