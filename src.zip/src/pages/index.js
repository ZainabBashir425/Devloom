import Home from "./HomePage/Home";

export {Home};