import logoipsum1 from './HomeAssets/logoipsum-265.png'
import logoipsum2 from './HomeAssets/logoipsum-264.png'
import logoipsum3 from './HomeAssets/logoipsum-244.png'
import logoipsum4 from './HomeAssets/logoipsum-262.png'
import logoipsum5 from './HomeAssets/logoipsum-250.png'
import Service from './HomeAssets/Service.png'
import RightArrow from './HomeAssets/RightArrow.png'
import RightArrowW from './HomeAssets/RightArrowW.png'
import TopRightArrow from './HomeAssets/TopRightArrow.png'
import TopRightArrowW from './HomeAssets/TopRightArrowW.png'
import Design1 from './HomeAssets/Design1.png'
import Design2 from './HomeAssets/Design2.png'
import Design3 from './HomeAssets/Design3.png'
import DesignArrow from './HomeAssets/DesignArrow.png'
import ProcessStar from './HomeAssets/ProcessStar.png'
import ProcessHStar from './HomeAssets/ProcessHStar.png'
export{logoipsum1,logoipsum2,logoipsum3,logoipsum4,logoipsum5,Service,TopRightArrow,RightArrow,RightArrowW,TopRightArrowW,Design1,Design2,Design3,DesignArrow,ProcessHStar,ProcessStar}

import Facebook from './FooterAssets/Facebook.png';
import LinkedIn from './FooterAssets/LinkedIn.png';
import Instagram from './FooterAssets/Instagram.png';
import Twitter from './FooterAssets/Twitter.png';

export{Facebook,LinkedIn,Instagram,Twitter}